#include"DoublyLinkedList.h"
template<class Type>
Node<Type>* findingtriplets(Node<Type>* head, int S)
{
	Node<Type>* temp = head;
	Node<Type>* i = temp;
	Node<Type>* j = i->next;
	Node<Type>* k = j->next;
	int sum = 0;
	cout << "The Triplets are ";
	for (i = temp; i != NULL; i=i->next)
	{
		for (j = i->next; j != NULL; j=j->next)
		{
			sum = 0;
			for (k = j->next; k != NULL; k=k->next)
			{
				sum = i->data + j->data + k->data;
				if (sum == S)
				{
					cout << "( "<<(i->data) << "," << (j->data) << "," << (k->data) << " ) ";
				}
			}
		}
	}
	cout << endl;
	return head;
}

int main()
{
	DoublyLinkedList<int>d1;
	int count = 0;
	int S = 0;
	int data;
	cout << "Enter Data " << endl;
	cin >> data;
	d1.insertAtFront(data);
	cin >> data;
	d1.insertAtEnd(data);
	cin >> data;
	d1.insertAtFront(data);
	cin >> data;
	d1.insertNext(2, data);
	cin >> data;
	d1.insertAtFront(data);
	cin >> data;
	d1.insertSorted(data);
	cin >> data;
	d1.insertAtEnd(data);
	d1.sorting();
	d1.display(d1.head);
	cout << "Enter  S Value " ;
	cin >> S;
    count=d1.SizeofList();
	/*cout << "The Size of Linked List is " << count << endl;*/
	findingtriplets(d1.head, S);
    system("pause");
	return 0;
	
}