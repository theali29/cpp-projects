#include"List.h"

int main()
{
	int nooflists;
	cout << "Enter number of linked lists you want to create" << endl;
	cin >> nooflists;
	int data;
	List<int>* l1 = new List<int>[nooflists];
	
	for (int i = 0; i < nooflists; i++)
	{
		cout << "Enter data" << endl;
		cin >> data;
		l1[i].head=l1[i].insertAtFront(l1[i].head,data);
		cout << "Enter data" << endl;
		cin >> data;
		l1[i].head=l1[i].insertAtEnd(l1[i].head,data);
		cout << "Enter data" << endl;
		cin >> data;
		l1[i].head=l1[i].insertsorted(data);
		//l1[i].sorting(l1[i].head);
		l1[i].PrintList();
	}
	cout << "After Merging " << nooflists <<" Linked Lists"<< endl;
	l1[0].merge(l1, nooflists);
	l1[0].PrintList();
	
	
system("pause");
return 0;
}
