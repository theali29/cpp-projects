#pragma once
#include"Node.h"
#include<iostream>
using namespace std;
template<class Type>
class List
{
	Node<Type>* head;
public:
	List(void)
	{
		head = NULL;
	}
	bool isempty()
	{
		return head = NULL;
	}
	void insertAtFront(Type x)
	{
		    Node<Type>* newnode = new Node<Type>;
			newnode->data = x;
			newnode->next = head;
			head = newnode;
    }
	void insertAtEnd(Type x)
	{
		Node<Type>* newnode = new Node<Type>;
		newnode->data = x;
		newnode->next = NULL;
		Node<Type>* temp = head;
		if (head == NULL) {
			head = newnode;
		}
		while (temp->next != NULL)
		{
			temp = temp->next;
		}
		
		temp->next = newnode;
    }
		
	void insertsorted(Type x)
    {
		Node<Type>* current = head;
		Node<Type>* newnode = new Node<Type>;
		newnode->data = x;
		newnode->next = NULL;
		while (head == NULL || current->data >= newnode->data)
		{
			newnode->next = head;
			head = newnode;
			return;
		}
		while (current->next != NULL && current->next->data < newnode->data)
		{
			current = current->next;
		}
		newnode->next = current->next;
		current->next = newnode;
	}
    void insertNext(Type Nodevalue, Type x)
	{
		Node<Type>* newnode = new Node<Type>;
		newnode->data = x;
		newnode->next = NULL;
		Node<Type>* temp = head;
		if (head == NULL) {
			head = newnode;
		}
		while (temp->data !=Nodevalue)
		{
			temp = temp->next;
        }
		newnode->next = temp->next;
		temp->next = newnode;
    }
	
	void sorting()
	{
		Node<Type>* temp = head;
		Node<Type>* i = temp;
		Node<Type>* j = i->next;
		for (i = temp; i != NULL; i = i->next) 
		{	
			for (j = i->next; j != NULL; j = j->next)
			{
				if (i->data >j->data)  
				{
					swap(i->data,j->data);

				}
			}
		}
	}
	
	Type removeFromFront()
	{
		int i = 0;
		Node<Type>* temp = head;
		if (head == NULL)
		{
			return NULL;
		}
		i = temp->data;
		head = temp->next;
	
		
		delete temp;
		return i;
	}
	int SizeOfList()
	{
		int count = 0;
		Node<Type>* temp = head;
		while (temp != NULL)
		{
			temp = temp->next;
			count++;
		}
		return count;
	}

	Type removeNext(Type Nodevalue)
	{
		Node<Type>* prevNode = NULL;
		Node<Type>* currNode = head;
		int currIndex = 1;
		while (currNode && currNode->data != Nodevalue)
		{
			prevNode = currNode;
			currNode = currNode->next;
			currIndex++;
		}
		prevNode = currNode;
		currNode = currNode->next;
		currIndex++;
		if (currNode) {
			if (prevNode) {
				
				prevNode->next = currNode->next;
				delete currNode;
			}
			
		}
		else
		{
			cout << "The next node is NULL" << endl;
			return -1;
		}
		
		return 0;
	}
	void removeFromEnd()
	{
		Node<Type>* prevNode = NULL;
		Node<Type>* temp = head;
		while (temp->next != NULL)
		{
			prevNode = temp;
			temp = temp->next;
		}
		prevNode->next = NULL;
		delete temp;
	
    }
	void insertbefore(Type Nodevalue, Type x)
	{
		Node<Type>* newnode = new Node<Type>;
		newnode->data =x;
		newnode->next = NULL;
		Node<Type>* curr = head;
		Node<Type>* prev=NULL;
		if (head == NULL)
		{
			head = newnode;
			return;
		}
		else if(head!=NULL&&curr->data==Nodevalue)
		{
			newnode->next = head;
			head = newnode;
			return;
		}
		else
		{
			while (curr->data != Nodevalue)
			{
				prev = curr;
				curr = curr->next;

			}
			newnode->next = prev->next;
			prev->next = newnode;
		}
	}
	void PrintList() 
	{
		Node<Type>* temp = head;
		if (temp != NULL) {
			cout << "The list contains: ";
			while (temp != NULL) {
				cout << temp->data << " ";
				temp = temp->next;
			}
			cout << endl;
		}
		else 
		{
			cout << "The list is empty.\n";
		}

	}
	Node<Type>*removeduplicate()
	{
		Node<Type>* temp = head;
		Node<Type>* prev = NULL;
		if (head == NULL)
		{
			return NULL;
		}
		while (temp->next != NULL)
		{
			if (temp->data == temp->next->data)
			{
				prev = temp->next;
				temp->next = temp->next->next;
				
			}
			else
			{
				prev = temp;
				temp = temp->next;
			}
		}
		return prev;

	}
	
};



