#include"List.h"
//void merge(List<type>* l1, List<type>* l2)
//{
//	
//	List<type>* temp = l1;
//	while (temp->next != NULL)
//	{
//		temp = temp->next;
//	}
//	temp->next = l2;
//}

//void insert(Node<Type>**head1, Type x)
//{
//
//	Node<Type>* newnode = new Node<Type>;
//	newnode->data = x;
//	newnode->next = *head1;
//	*head1 = newnode;
//	
//}
//template <class Type>
//void nsorting(Node<Type>* head12)
//{
//
//	Node<Type>* temp = head12;
//	Node<Type>* i = temp;
//	Node<Type>* j = i->next;
//	for (i = temp; i != NULL; i = i->next)
//	{
//		for (j = i->next; j != NULL; j = j->next)
//		{
//			if (i->data > j->data)
//			{
//				swap(i->data, j->data);
//
//			}
//		}
//	}
//}
//
//template <class Type>
//Node<Type>* SortedMerge(Node<Type>* a, Node<Type>* b)
//{
//	
//	Node <Type>dummy;
//    Node<Type>* tail = &dummy;
//    dummy.next = NULL;
//	while (a!=NULL&&b!=NULL)
//	{
//		
//		if (a->data <= b->data)
//        {
//			tail->next = a;
//			a = a->next;
//		}
//		else     
//		{
//			tail->next = b;
//			b = b->next;
//
//		}
//
//		tail = tail->next;
//	}
//	while (a != NULL)
//	{
//
//		tail->next = a;
//		a = a->next;
//		
//	}
//	while (b != NULL)
//	{
//		tail->next = b;
//		b = b->next;
//	}
//	return dummy.next;
//}
//template<class Type>
//Node<Type>* reverseList(Node<Type>*head)
//{
//	Node<Type>* curr = head;
//	Node<Type>* prev = NULL;
//	Node<Type>* temp;
//	while (curr != NULL)
//	{
//		temp = curr->next;
//		curr->next = prev;
//		prev = curr;
//		curr = temp;
//	
//	}
//	return prev;
//}
//template<class Type>
//Node<Type>* Middle(Node<Type>* head)
//{
//	Node<Type>* fast = head;
//	Node<Type>* slow = head;
//	while (fast != NULL)
//	{
//		fast = fast->next->next;
//		slow = slow->next;
//	}
//	return slow;
//}
//
//template<class Type>
//void insertinCiruclar(Node<Type>**head1,Type x)
//{
//	Node<Type>* newnode = new Node<Type>;
//	Node<Type>* ptr = *head1;
//	newnode->data = x;
//	newnode->next = *head1;
//	if (*head1 == NULL)
//	{
//		newnode->next = newnode;
//		*head1 = newnode;
//	}
//	else
//	{
//		while (ptr->next!= *head1)
//		{
//			ptr = ptr->next;
//			ptr->next = newnode;
//		}
//	}
//}
//
//template<class Type>
//void display(Node<Type>* head)
//{
//	Node<Type>* temp = head;
//	if (temp != NULL)
//	{
//		while (temp != NULL)
//		{
//			cout << temp->data << " ";
//			temp = temp->next;
//		}
//		cout << endl;
//	}
//}
//
//
//template<class Type>
//bool palindromic(Node<Type>* head)
//{
//	Node<Type>* first = head;
//	Node<Type>* Mid = Middle(head->next);
//	Node<Type>* last = reverseList(Mid);
//
//	while (last != NULL)
//	{
//		if (first->data != last->data)
//		{
//			return false;
//		}
//			first = first->next;
//			last = last->next;
//	}
//	return true;
//	
//}
//


int main()
{
	/*int nooflists = 3;
	cout << "Enter number of linked lists you want to create" << endl;
	cin >> nooflists;
	int data;
	List<int>* l1 = new List<int>[nooflists];
	for (int i = 0; i < nooflists; i++)
	{
		cout << "Enter data" << endl;
		cin >> data;
		l1[i].insertAtFront(data);
		cout << "Enter data" << endl;
		cin >> data;
		l1[i].insertAtEnd(data);
		cout << "Enter data" << endl;
		cin >> data;
		l1[i].insertsorted(data);
		l1[i].PrintList();
	}
	*/
	List<int>l1;
	l1.insertAtFront(10);
	l1.insertAtEnd(12);
	l1.insertAtEnd(13);
	l1.insertAtEnd(10);
	l1.insertAtEnd(13);
	l1.insertAtFront(10);
	l1.insertsorted(1);
	List<int>l3;
	 l1.removeduplicate();
system("pause");
return 0;
}
