#include"DoublyLinkedList.h"
//template<class Type>
//Node<Type>* findingtriplets(Node<Type>* head, int S)
//{
//	Node<Type>* temp = head;
//	Node<Type>* i = temp;
//	Node<Type>* j = i->next;
//	Node<Type>* k = j->next;
//	int sum = 0;
//	cout << "The Triplets are ";
//	for (i = temp; i != NULL; i=i->next)
//	{
//		for (j = i->next; j != NULL; j=j->next)
//		{
//			sum = 0;
//			for (k = j->next; k != NULL; k=k->next)
//			{
//				sum = i->data + j->data + k->data;
//				if (sum == S)
//				{
//					cout << "( "<<(i->data) << "," << (j->data) << "," << (k->data) << " ) ";
//				}
//			}
//		}
//	}
//	cout << endl;
//	return head;
//}
template<class Type>
void alternatingsplit(Node<Type>* n1, Node<Type> * n2) {
	
	if (n1 == NULL || n2 == NULL) {
		return;
	}
	if (n1->next != NULL)
	{
		if (n1->next->next != NULL)
		{
			n1->next->next->prev = n1;
			n1->next = n1->next->next;
		}
		else
		{
			n1->next = NULL;
		}
	}
	if (n2->next != NULL) {
		if (n2->next->next != NULL)
		{
			n2->next->next->prev = n2;
			n2->next = n2->next->next;
		}
		else
		{
			n2->next = NULL;
		}
	}
	alternatingsplit(n1->next, n2->next);
}
template<class Type>
void splitList(Node<Type>* head, Node<Type>** n1, Node<Type>** n2)
{
	*n1 = head;
	*n2 = head->next;
	alternatingsplit(*n1, *n2);
}
//splitwithoutrecursion
//template<class Type>
//Node<Type> *sssplit(Node<Type>* head)
//{
//	DoublyLinkedList<int>d1;
//	if (head == NULL)
//		return NULL;
//	Node<Type>* head2;
//	Node<Type>* temp = head;
//	Node<Type>* temp2 = head->next;
//	temp2->prev = NULL;
//	head2 = temp2;
//	while (temp->next != NULL||temp2->next!=NULL)
//	{
//		if (temp->next->next != NULL)
//		{
//			temp->next->next->prev = temp;
//			temp->next = temp->next->next;
//
//		}
//		else
//		{
//			temp->next = NULL;
//		}
//		if (temp2->next == NULL)
//		{
//			break;
//		}
//		if (temp2->next->next != NULL)
//		{
//			temp2->next->next->prev = temp2;
//			temp2->next = temp2->next->next;
//		}
//		else
//		{
//			temp2->next = NULL;
//		}
//		if (temp->next != NULL && temp2->next != NULL)
//		{
//			temp = temp->next;
//			temp2 = temp2->next;
//		}
//		else
//		{
//			break;
//		}
//
//	}
//	d1.display(head);
//	d1.display(head2);
//	return temp,temp2;
//}
int main()
{
	DoublyLinkedList<int>d1;
	int count = 0;
	int S = 0;
	int data;
	Node<int>* a = NULL;
	Node<int>* b = NULL;
	cout << "Enter Data " << endl;
	cin >> data;
	d1.insertAtFront(data);
	cin >> data;
	d1.insertAtEnd(data);
	cin >> data;
	d1.insertAtFront(data);
	cin >> data;
	d1.insertAtFront(data);
	/*d1.insertNext(2, data);*/
	cin >> data;
	d1.insertAtFront(data);
	cin >> data;
	d1.insertSorted(data);
	cin >> data;
	d1.insertAtEnd(data);
	cin >> data;
	/*d1.insertbefore(9,data);*/
	d1.insertAtEnd(data);
	cin >> data;
	d1.insertAtEnd(data);
	d1.sorting();
	cout << "Input DLL is ";
	d1.display(d1.head);
	
	/*sssplit(d1.head);*/
	splitList(d1.head, &a, &b);
	cout << "After Splitting " << endl;
	cout << "DLL 1:";
	d1.display(a);
	cout << "DLL 2:";
	d1.display(b);
	/*cout << "Enter  S Value " ;
	cin >> S;*/
    //count=d1.SizeofList();
	/*cout << "The Size of Linked List is " << count << endl;*/
	/*findingtriplets(d1.head, S);*/
    system("pause");
	return 0;
	
}