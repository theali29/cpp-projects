#pragma once
#include"Node.h"
template<class T>
class RBT
{
public:
	Node<T>* root;
	RBT()
	{
      root = NULL;
	}
	void insert(const T&data);
	void search(Node<T>* root);
	void inorder(Node<T>* root);
	void inorder2(Node<T>* root);
	void postorder(Node<T>* root);
	void postorder2(Node<T>* root);
	void preorder(Node<T>* root);
	void preorder2(Node<T>* root);
	void readFile();
	void destroy(Node<T>* root);
	void delete_duplicate(Node<T>* root);
	void display_parent(Node<T>* root);
};

template<class T>
Node<T>* BSTInsert(Node<T>* root, Node<T>* pt)
{
    /* If the tree is empty, return a new node */
    if (root == NULL)
    {

        pt->color = 0;
        return pt;
    }
    /* Otherwise, recur down the tree */
    if (pt->data < root->data)
    {
        root->left = BSTInsert(root->left, pt);
        pt->color = 1;
        root->left->parent = root;
    }
    else if (pt->data > root->data)
    {
        root->right = BSTInsert(root->right, pt);
        pt->color = 1;
        root->right->parent = root;
    }

    /* return the (unchanged) node pointer */
    return root;
}
template<class T>
void rotateLeft(Node<T>*& root, Node<T>*& pt)
{
    Node<T>* pt_right = pt->right;
    pt->right = pt_right->left;
    if (pt->right != NULL)
       pt->right->parent = pt;

    pt_right->parent = pt->parent;

    if (pt->parent == NULL)
        root = pt_right;

    else if (pt == pt->parent->left)
        pt->parent->left = pt_right;

    else
        pt->parent->right = pt_right;

    pt_right->left = pt;
    pt->parent = pt_right;
}
template<class T>
void rotateRight(Node<T>*& root, Node<T>*& pt)
{
    Node<T>* pt_left = pt->left;

    pt->left = pt_left->right;

    if (pt->left != NULL)
        pt->left->parent = pt;

    pt_left->parent = pt->parent;

    if (pt->parent == NULL)
        root = pt_left;

    else if (pt == pt->parent->left)
        pt->parent->left = pt_left;

    else
        pt->parent->right = pt_left;

    pt_left->right = pt;
    pt->parent = pt_left;
}
template<class T>
void fixViolation(Node<T>*& root, Node<T>*& pt)
{
    Node<T>* parent_pt = NULL;
    Node<T>* grand_parent_pt = NULL;

    while ((pt != root) && (pt->color == 1) &&
        (pt->parent->color == 1))
    {

        parent_pt = pt->parent;
        grand_parent_pt = pt->parent->parent;

        /*  Case : A
            Parent of pt is left child
            of Grand-parent of pt */
        if (parent_pt == grand_parent_pt->left)
        {

            Node<T>* uncle_pt = grand_parent_pt->right;

            /* Case : 1
               The uncle of pt is also red
               Only Recoloring required */
            if (uncle_pt != NULL && uncle_pt->color ==
                1)
            {
                grand_parent_pt->color = 1;
                parent_pt->color = 0;
                uncle_pt->color = 0;
                pt = grand_parent_pt;
            }

            else
            {
                /* Case : 2
                   pt is right child of its parent
                   Left-rotation required */
                if (pt == parent_pt->right)
                {
                    rotateLeft(root, parent_pt);
                    pt = parent_pt;
                    parent_pt = pt->parent;
                }

                /* Case : 3
                   pt is left child of its parent
                   Right-rotation required */
                rotateRight(root, grand_parent_pt);
                swap(parent_pt->color,
                    grand_parent_pt->color);
                pt = parent_pt;
            }
        }

        /* Case : B
           Parent of pt is right child
           of Grand-parent of pt */
        else
        {
            Node<T>* uncle_pt = grand_parent_pt->left;

            /*  Case : 1
                The uncle of pt is also red
                Only Recoloring required */
            if ((uncle_pt != NULL) && (uncle_pt->color ==
                1))
            {
                grand_parent_pt->color = 1;
                parent_pt->color = 0;
                uncle_pt->color = 0;
                pt = grand_parent_pt;
            }
            else
            {
                /* Case : 2
                   pt is left child of its parent
                   Right-rotation required */
                if (pt == parent_pt->left)
                {
                    rotateRight(root, parent_pt);
                    pt = parent_pt;
                    parent_pt = pt->parent;
                }

                /* Case : 3
                   pt is right child of its parent
                   Left-rotation required */
                rotateLeft(root, grand_parent_pt);
                swap(parent_pt->color,
                    grand_parent_pt->color);
                pt = parent_pt;
            }
        }
    }

    root->color = 0;
}

template<class T>
void RBT<T>::insert(const T& data)
{
    Node<T>* pt = new Node<T>;
    pt->data = data;
    pt->right = NULL;
    pt->left = NULL;
    // Do a normal BST insert
    root = BSTInsert(root, pt);

    // fix Red Black Tree violations
    fixViolation(root, pt);
}
template<class T>
void RBT<T>::inorder(Node<T>* root)
{
    //LNR
    Node<T>* newnode = root;
    if (newnode == NULL)
        return;
    inorder(newnode->left);
    cout << newnode->data<< "(" << newnode->color << ")" << " ";
    inorder(newnode->right);
}
template<class T>
void RBT<T>::inorder2(Node<T>* root)
{
    //RNL

    Node<T>* newnode = root;
    if (newnode == NULL)
        return;
    inorder2(newnode->right);
    cout << newnode->data<< "(" << newnode->color << ")" << " ";
    inorder2(newnode->left);
    
}
template<class T>
void RBT<T>::preorder(Node<T>* root)
{
    //NLR
    Node<T>* newnode = root;
    if (newnode == NULL)
        return;
    cout << newnode->data<<"(" << newnode->color << ")" << " ";
    preorder(newnode->left);
    preorder(newnode->right);
}
template<class T>
void RBT<T>::preorder2(Node<T>* root)
{
    //NRL
    Node<T>* newnode = root;
    if (newnode == NULL)
        return;
    cout << newnode->data<<"(" << newnode->color << ")" << " ";
    preorder2(newnode->right);
    preorder2(newnode->left);
 
}
template<class T>
void RBT<T>::postorder(Node<T>* root)
{
    //LRN
    Node<T>* newnode = root;
    if (newnode == NULL)
        return;
    postorder(newnode->left);
    cout << newnode->data << "(" << newnode->color << ")"<< " ";
    postorder(newnode->right);
}
template<class T>
void RBT<T>::postorder2(Node<T>* root)
{
    //RLN
    Node<T>* newnode = root;
    if (newnode == NULL)
        return;
    cout << newnode->data<<"("<<newnode->color<<")" << " ";
    postorder2(newnode->right);
    postorder2(newnode->left);

}