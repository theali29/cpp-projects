#include"RBT.h"
int main()
{
	RBT<int> R1;
	R1.insert(10);
	R1.insert(18);
	R1.insert(7);
	R1.insert(15);
	R1.insert(16);
	R1.insert(30);
	R1.insert(25);
	R1.insert(40);
	R1.insert(60);
	R1.insert(2);
	R1.insert(1);
	R1.insert(70);


	R1.preorder2(R1.root);
}