#pragma once
#include"StackADT.h"
#include<iostream>
using namespace std;
template<class type>

class MyStack :public StackADT<type>
{
public:
	MyStack()
	{
		StackADT<type>::arr = new type[10];
		StackADT<type>::maxSize = 10;
		StackADT<type>::stackTop = -1;
	}
	MyStack(int size)
	{
		StackADT<type>::arr = new type[size];
		StackADT<type>::maxSize = size;
		StackADT<type>::stackTop = -1;
	}
	bool isempty()
	{
		if (StackADT<type>::stackTop == -1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	bool isfull()
	{
		if (StackADT<type>::stackTop == StackADT<type>::maxSize - 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	void push(type x)
	{
		if (!isfull())
		{
			StackADT<type>::stackTop++;
			StackADT<type>::arr[StackADT<type>::stackTop] = x;
		}
		else
		{
			cout << "Stack is full" << endl;
		}
	}
	type pop()
	{
		if (!isempty())
		{
			StackADT<type>::stackTop--;
			return StackADT<type>::arr[StackADT<type>::stackTop];
		}
		else
		{
			cout << "Stack is empty" << endl;
			return 0;
		}
	}
	type top()
	{
		if (!isempty())
		{
			return StackADT<type> ::arr[StackADT<type> ::stackTop];
		}
		else
		{
			cout << "Stack is empty \n";
			return 0;
		}
	}
	
};


