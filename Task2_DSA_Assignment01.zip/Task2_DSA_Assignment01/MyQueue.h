#pragma once
#include"MyStack.h"
#include<iostream>
using namespace std;
template<class type>
class MyQueue
{
public:
	MyStack<int> stack1, stack2;
	void push(type x)
	{
		stack1.push(x);

	}
	type pop()
	{
		type x, y;
		if (stack1.isempty() && stack2.isempty())
		{
			cout << "Queue is empty " << endl;
		}
		if (stack2.isempty())
		{
			while (!stack1.isempty())
			{
				y = stack1.top();
				stack2.push(y);
				stack1.pop();
				
			}
		}
		x = stack2.top();
	
		stack2.pop();
		
		return x;
	}
	

};

