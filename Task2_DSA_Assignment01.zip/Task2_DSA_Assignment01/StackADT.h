#pragma once
template<class type>
class StackADT
{
public:	type* arr;
	int maxSize;
	int stackTop;
public:
	virtual void push(type) = 0;
	virtual type pop() = 0;
	virtual type top() = 0;

};

