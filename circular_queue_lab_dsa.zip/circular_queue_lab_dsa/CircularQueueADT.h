template<class type>
class CircularQueueADT
{
protected:
	type* arr;
	int front;
	int rear;
	int maxSize;
	int elements;
public:
	virtual void enqueue(type) = 0;
	virtual type dequeue() = 0;


};