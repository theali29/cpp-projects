#pragma once
#include"CircularQueueADT.h"
#include<iostream>
using namespace std;

template<class type>

class MyCircularQueue :public CircularQueueADT<type>
{
	int rear = 0;
	int front = 0;
public:
	MyCircularQueue()
	{
		CircularQueueADT<type>::arr = new type[10];
		CircularQueueADT<type>::maxSize = 10;
		CircularQueueADT<type>::elements = 0;

	}
	MyCircularQueue(int size)
	{
		CircularQueueADT<type>::arr = new type[size];
		CircularQueueADT<type>::maxSize = size;
		CircularQueueADT<type>::elements = 0;
	}
	bool isempty()
	{
		if (CircularQueueADT<type>::elements == 0) {
			return true;
		}
		else {
			return false;
		}
	}

	bool isfull()
	{
		if (CircularQueueADT<type>::elements == CircularQueueADT<type>::maxSize)
		{
			return true;
		}
		else {
			return false;
		}
	}
	int size()
	{
		return CircularQueueADT<type>::maxSize;
	}
	type Front()
	{
		return CircularQueueADT<type>::arr[CircularQueueADT<type>::front];
	}
	void enqueue(type x)
	{
		CircularQueueADT<type>::rear = CircularQueueADT<type>::rear % CircularQueueADT<type>::maxSize;
		CircularQueueADT<type>::arr[CircularQueueADT<type>::rear++] = x;
		CircularQueueADT<type>::elements++;

	}
	type dequeue()
	{
		CircularQueueADT<type>::front = CircularQueueADT<type>::front % CircularQueueADT<type>::maxSize;
		CircularQueueADT<type>::elements--;
		return CircularQueueADT<type>::arr[CircularQueueADT<type>::front++];

	}
	void display()
	{
		if (isempty())
		{
			cout << "Circular Queue is empty : \n";
		}
		else
		{
			cout << "Total number of elements in Circular Queue are : " << CircularQueueADT<type>::elements << '\n';
			cout << "Maximum size of stack is " << CircularQueueADT<type>::maxSize << '\n';
			for (int i = 0; i < CircularQueueADT<type>::elements; i++)
			{
				cout << i << ". " << CircularQueueADT<type>::arr[i] << '\n';
			}

		}
	}
	void sortqueue()
	{
		for (int i = 0; i < CircularQueueADT<type>::elements; i++)
		{
			int index = i;
			for (int j = 0; j < CircularQueueADT<type>::elements; j++)
			{
				if (CircularQueueADT<type>::arr[j] > CircularQueueADT<type>::arr[index])
				{
					type temp = CircularQueueADT<type>::arr[index];
					CircularQueueADT<type>::arr[index] = CircularQueueADT<type>::arr[j];
					CircularQueueADT<type>::arr[j] = temp;
				}
			}
		}
	}



};