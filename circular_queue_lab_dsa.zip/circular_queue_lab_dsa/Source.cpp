#include"MyCircularQueue.h"
int main()
{
	MyCircularQueue<int>c1;
	c1.enqueue(23);
	c1.enqueue(17);
	c1.enqueue(56);
	c1.enqueue(32);
	c1.display();
	c1.sortqueue();
	cout << "The sorted Circular Queue is " << endl;
	c1.display();
	c1.dequeue();
	c1.display();
}