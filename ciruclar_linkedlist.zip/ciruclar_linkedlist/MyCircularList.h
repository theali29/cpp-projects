#pragma once
#include"Node.h"
#include<iostream>
using namespace std;
template<class Type>
class MyCircularList
{ 

public:
		Node<Type>* tail;
	public:
		MyCircularList(void)
		{
			tail = NULL;
		}
		bool isempty()
		{
			return tail = NULL;
		}
		void insertAtFront(Type x)
		{
			Node<Type>* newnode = new Node<Type>;
			newnode->data = x;
			if (tail == NULL)
			{

				tail = newnode;
				tail->next = tail;
			}
			else
			{
				newnode->next = tail->next;
				tail->next = newnode;
			}
		}
		void insertAtEnd(Type x)
		{
			Node<Type>* newnode = new Node<Type>;
			newnode->data = x;
			if (tail == NULL)
			{
				tail = newnode;
				tail->next = tail;
			}
			newnode->next = tail->next;
			tail->next = newnode;
			tail = newnode;
		}
		void insertbefore(Type Nodevalue, Type x)
		{
			Node<Type>* newnode = new Node<Type>;
			newnode->data = x;
	
			Node<Type>* curr = tail->next;
			Node<Type>* prev = tail;
			if (tail==NULL)
			{
				tail = newnode;
				tail->next = newnode;
				return;
			}
			else if (tail != NULL && curr->data == Nodevalue)
			{
				newnode->next = tail->next;
				tail->next = newnode;
				return;
			}
			else
			{
				while (curr->data!=Nodevalue)
				{
					prev->next = curr;
					curr=curr->next;
					prev = prev->next;
				}
				newnode->next = prev->next;
				prev->next = newnode;

			}

		}
		void insertnext(Type value, Type x)
		{
			Node<Type>* newnode = new Node<Type>;
			Node<Type>* temp = tail->next;
			newnode->data = x;

			if (tail == NULL)
			{
				tail = newnode;
				tail->next = newnode;
				return;
			}
			while (temp->data != value)
			{
				temp = temp->next;
			}
			if (temp->next == tail->next)
			{
				newnode->next = temp->next;
				temp->next = newnode;
				tail = newnode;

			}
			else
			{
				newnode->next = temp->next;
				temp->next = newnode;
			}
		}
		Type removefromFront()
		{
			Node<Type>* temp = tail->next;
			if (tail == NULL)
			{
				return NULL;
			}
			int i = temp->data;
			tail->next = temp->next;
			delete temp;
			return i;
		}
		void insertsorted(Type x)
		{
			Node<Type>* current = tail->next;
			Node<Type>* newnode = new Node<Type>;
			newnode->data = x;
			
			while (tail == NULL || current->data >= newnode->data)
			{
				if (tail == NULL)
				{
					tail = newnode;
					tail->next = tail;
					return;
				}


				else
				{
					newnode->next = tail->next;
					tail->next = newnode;
					return;
				}
			}
			while (current->next != tail->next && current->next->data < newnode->data){
				current = current->next;
			}
			if (tail->next == current->next)
			{
				newnode->next = current->next;
				current->next = newnode;
				tail = newnode;
			}
			else
			{
				newnode->next = current->next;
				current->next = newnode;
			}
		}
		Node<Type>*middle()
		{
			Node<Type>* fast = tail->next;
			Node<Type>* slow = tail->next;
			while (fast->next != tail->next)
			{
				fast = fast->next->next;
				slow = slow->next;
			}
			return slow;
		}
		Node<Type>* reverse(Node<Type>* head)
		{
			Node<Type>* curr = head;
			Node<Type>* prev = head;
			Node<Type>* temp;
			do
			{
				temp = curr->next;
				curr->next = prev;
				prev = curr;
				curr = temp;
			} while (curr->next != tail->next);

				if (tail->next == curr->next)
				{
					temp = curr->next;
					curr->next = prev;
					prev = curr;
					curr = temp;
					curr->next = prev;
					
					prev = curr;
					tail = prev;
				}
				

			return prev;

		}

	
		bool checkpalindrome()
		{
			Node<Type>* temp = tail->next;
			Node<Type>* mid = middle();
			Node<Type>* rev = reverse(mid->next);
			
			while (rev!=temp)
			{
				if (temp->data!=rev->data)
				{
					return false;
				}
				temp = temp->next;
				rev = rev->next;
			}
			return true;

		}
		Type removefromEnd()
		{
			int i = 0;
			Node<Type>* prev = NULL;
			Node<Type>* temp = tail->next;
			if (tail == NULL)
			{
				return NULL;
			}
			while (temp->next!=tail->next)
			{
				prev = temp;
				temp = temp->next;
			}
			i = temp->data;
			
			prev->next = tail->next;
			tail = prev;
			delete temp;
			
			return i;
		}
		Type removeNext(Type Nodevalue)
		{
			int i = 0;
			Node<Type>* prev = NULL;
			Node<Type>* temp = tail->next;
			if (tail == NULL)
			{
				return NULL;
			}
			while (temp->data!=Nodevalue&&temp->next!=tail->next)
			{
				prev = temp;
				temp = temp->next;
				
			}
			if (temp->next == tail->next)
			{
				i = temp->next->data;

				prev->next = tail->next;
				tail = prev;
				delete temp;

				return i;
			}
			else
			{
				prev = temp;
				temp = temp->next;
				i = temp->data;

				prev->next = temp->next;
				return i;
			}
		}
		void sort()
		{

			Node<Type>*temp= tail->next;
			Node<Type>* i = temp;
			Node<Type>* j = i->next;
			for (i = temp; i != tail; i = i->next)
			{
				for (j = i->next; j != tail->next;j= j->next)
				{
					if (i->data > j->data)
					{
						swap(i->data, j->data);

					}
				}
			}
			/*do
			{
				j = i->next;
				while (j != tail->next)
				{
					if (i->data > j->data)
					{
						swap(i->data, j->data);

					}
					j = j->next;
				}
			i= i->next;
			} while (i != tail->next);*/

		}
		void display()
		{
			Node<Type>* temp = tail->next;
			do {
				cout << temp->data<<" ";
				temp = temp->next;
			} while (temp != tail->next);
			cout << endl;
			
		}
		
		

};

