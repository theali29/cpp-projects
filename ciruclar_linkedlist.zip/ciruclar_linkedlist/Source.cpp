#include"MyCircularList.h"

//void insert(Node<Type>** head,Type x)
//{
//	Node<Type>* newnode = new Node<Type>;
//	newnode->data = x;
//	Node<Type>* temp;
//	if (*head ==NULL)
//	{
//
//		Node<Type>::tail = newnode;
//		Node<Type>::tail->next = newnode;
//		*head = Node<Type>::tail;
//return *head;
//	}
//	else 
//	{
//		
//		temp = Node<Type>::tail->next;
//		while (Node<Type>::tail->next != temp->next)
//		{
//			temp = temp->next;
//		}
//		if (Node<Type>::tail->next == temp->next)
//		{
//			newnode->next = Node<Type>::tail->next;
//			Node<Type>::tail->next = newnode;
//			Node<Type>::tail = newnode;
//			*head = Node<Type>::tail;
//			return *head;
//		}
//
//	}
//
//
//}
//template<class Type>
//void display(Node<Type>* head)
//{
//	Node<Type>* temp = head->next;
//	
//	do {
//		cout << temp->data << " ";
//		temp = temp->next;
//	} while (temp !=head->next);
//	cout << endl;
//}
//template<class Type>
//void nsorting(Node<Type>*head)
//{
//	Node<Type>* temp =head->next;
//	Node<Type>* i = temp;
//	Node<Type>* j = i->next;
//	for (i = temp; i != head; i = i->next)
//	{
//		for (j = i->next; j !=head->next; j = j->next)
//		{
//			if (i->data > j->data)
//			{
//				swap(i->data, j->data);
//
//			}
//		}
//	}
//}
int main()
{
	MyCircularList<int>c1;
	c1.insertAtFront(10);
	c1.insertAtFront(5);
	c1.insertAtFront(2);
	int data = 0;
	c1.insertAtEnd(30);
	c1.insertAtFront(40);
	c1.insertnext(30, 25);
	c1.insertbefore(25, 29);
	c1.insertsorted(50);
	c1.display();
	c1.sort();

	cout << "Sorted Linked List" << endl;
	c1.display();
	data = c1.removefromFront();
	cout << data << " element is removed from Front" << endl;
c1.display();
data = c1.removefromEnd();
cout << data << " element is removed from End"<<endl;

c1.display();

data = c1.removeNext(10);
cout << data << " element is removed from Next" << endl;


MyCircularList<int>c2;
c2.insertAtFront(2);
c2.insertAtFront(5);
c2.insertAtFront(7);
c2.insertAtFront(5);
c2.insertAtFront(2);

c2.display();
bool a;
a = c2.checkpalindrome();
if (a == true)
{
	cout << "Linked List is Palindromic " << endl;
}
else
{
	cout << "Linked List is not Palindromic " << endl;
}

//Node<int>* head1 = NULL;
//insert(&head1, 4);
//insert(&head1, 7);
//insert(&head1, 1);
//insert(&head1, 5);
//display(head1);
//nsorting(head1);
	system("pause");
	return 0;
}